# 终极愿景 vs 现在（对照）

北极星（用户原话，以此为准）：

> 一门**新的**、**语法和原语极简**、**复杂度交给编译器**、带**动态插件系统**、服务 **coding agent** 的**内联汇报语言**。  
> 同一套语言必须**同时**做到：
>
> 1. **游戏式丰富交互**
> 2. **论文级精美图表**
> 3. **图像 / 视频级排版**

默认内联体验仍是 `print-nature` + **可交互 Runtime**，不是一张静态 PNG。

本文只做对照。**不要**把接口齐当成愿景齐。

---

## 1. 愿景要的是一门语言，不是三套 demo

| 柱 | 愿景里的样子 | 今天实际 | 差在哪 |
| --- | --- | --- | --- |
| 交互 | 汇报件本身就是活世界：点、刷、拖、联动、时间，和游戏同一套原语 | Runtime 有 click/hover/drag/collide/key/tick；世界手：点/拖 slop、`__hand` 握持、扫掠顶住、切向滑墙、编组共享一步、套索橡皮筋；图表默认跟手 `__tip`（`__tipX`/`__tipY` 为作者场景单位） / `__hover` / `__brush`（数据域） / `__highlightGrp`；挂了 `frame:` 的 World 点走同一套（投影坐标不绑 brush） | 手仍不是 Unity 输入栈；刷选还不是完整 linked selection；无动画过渡；内联卡上的检查/修复壳仍弱 |
| 图表 | 轴、误差、分组、色标、投稿可读，由编译器长出来 | `chart.scatter/line/bar/heatmap/vector/funnel/box/violin` + 线性/log/band/time；轴标题在场景坐标；violin 为 KDE 轮廓；`print-nature` 接管刻度/轴标题字号与字距；PDF 优先随包 CJK 全库，宿主可覆盖 | 布局仍用 `0.58 × font` 假字宽；SVG/PDF 字体和 paint 能力不一致；不是投稿成品 |
| 排版 | 作者只说「2×2 图、单栏 89 mm、安全框」；格子、出血、字幕条、对位由编译器算 | `layout.figure` 网格（不写 `inset*` 时按绑定 chart 估留白）；`layout.board` 安全框 + `splits` / `beats` / `bleed` / `typeGrid`（不写 `safe`/`titleH`/`lowerH` 时按题注和芯片估条带）；`unit: mm` + 单/双栏；`page: a4` PDF 切片 + `n / N` 页戳；figure 格子避开页缝；beat PNG 取 Clock hold 中点，GIF/MP4 按 timeline fps 采完整 hold+ease | 页装箱不是栏宽重排；估 inset ≠ 真实字体约束；PDF 丢 rotate/gradient/dash 等；Runtime 没有页面导航 |
| 语法 | 原语极小，新能力只加插件名 | 核还算小；widget 走 `registerWidget()` | 语言表面没涨关键字。不要为图种/槽位加关键字 |
| 编译器 | 度量、避让、对齐、交互默认、导出保真全在编译/运行时 | band/log/linear + handbook 涂颜料/接管字号字距 + 图核默认交互 | handbook **仍不**执行图语法（避让、对齐、栏宽文法）；导出保真仍有缺口 |
| 插件 | 宿主运行时注册：图种、排版、领域视图，agent 可发现 | 手册 / 领域视图 / 结构宏都可注册 | 还不是热加载 / 沙箱包；未知 widget 编译失败并列出已注册名 |
| Agent | 内联写短意图 → 编译 → 交互卡 → 检查 → 补丁 | CLI / MCP / HTTP / SDK 能编能导；prompt 默认 slim；MCP/HTTP compile 附 raster visual QA（空栏看 figure cell）；结构层用 CSS px + 旋转感知盒子警告 chrome 出格 | visual 错误失败 compile success；LLM 生成率用 key 实测；chromeOverflow 仍是警告 |

一句话：今天是 **World + Space + Paint** 粘在一起，脊柱已能同时展开三柱，但出版观感与 agent 闭环都还没齐。愿景是 **同一套极小原语**，三柱都是编译器展开，插件只换展开器。

---

## 2. 为什么不能靠加关键字

错误路径（已经踩过苗头）：

- 为「像论文」加 `figure` / `panel` / `colorbar` 关键字
- 为「像视频」加 `safe` / `lowerThird` 关键字
- 为「像游戏」把每个玩法写成语法

正确路径（设计真源，见 `DESIGN.md`）：

```
作者 / agent 只写：世界是什么、数据是什么、用哪个插件宏
         ↓
   widget / handbook / domain view   ← 动态插件
         ↓
   Compiler 展开成 node / frame / event
         ↓
   Runtime 负责交互、度量、图层、时间
```

对齐这一条的具体动作：

- `registerWidget()` / `listWidgets()`（`src/plugins/registry.ts`）
- 内置插件：`timeline`、`chart.*`（含 vector/funnel）、`layout.figure`、`layout.board`
- 图表用 `panel: a` 吃排版插件吐出的 frame，或吃作者 `role: panel` / `role: plot` 升成的同名 frame，不再强迫手写 `areaX/areaY`
- `layout.*` 先于 `chart.*` 展开，源码顺序无所谓

**没有**新增语言关键字。`widget layout.figure` 只是一个插件名。

---

## 3. 三柱各自还缺什么（按用户看得见的质量）

### 3.1 游戏式交互

有：节点可拖、碰撞、键盘、tick、图层；图表默认数据域 tooltip、brush 反演（按 frame 隔离，同名 xField 联动）、跨面板 group 高亮、点图例高亮。挂了 `frame:` 的 World 点（`role: mark` / `colorBy`）默认同一套 `__tip` / `__hover` / `__highlightGrp` / `__sel`；`x`/`y` 是数据字段且平面上没有作者拖轨道时再绑 brush；作者没画图例时编译器按 `colorBy` 补可点图例。`role: plot` 复用 `title` / `controls` / `bind`，编译器画题注带和芯片；数值 `bind` 的 `+`/`-` 增减而不是写成字符串。有效刷选松手后保持选择窗；拖路径明显长于对角时用套索，否则矩形。  
没有：完整游戏级过渡曲线。内联卡有只读结构检查条，仍无 visual/raster、也没有自动修复。`__sel.keys` 默认让其它面板 **藏行**（含 box / violin / 折线 / 热图 / 柱 / 矢量；box 四分位、violin KDE、折线线段、热图均值、漏斗合计和矢量位移按选中行重算；`link: dim` 可改回变淡）。Runtime 用 CSS `opacity` + 命中组 `scale` 做 220ms 缓动（含 `layout.board play` 拍遮罩）；全部拍遮罩 `pointer-events: none`，暗着的拍也能 tooltip/brush。`paper-storyboard` 把 183×103 mm 分镜和同一套 `__sel` 放在一件里。box / 折线摘要几何和同骨架 violin 路径 `d` 也按同一时段插值；命令骨架不同则硬切。静态导出仍硬切。不是时间轴。

### 3.2 论文级图表

有：线性 / log / band / time 轴、scatter/line/bar/heatmap/vector/funnel/box、轴标题/单位（未加引号的多词 `xLabel: Sum score` 会拼成一句）、线性轴键上 `xlim`/`ylim` 端点、柱/箱/小提琴整数类目刻在取值上（不画 `xlim` 空位）、折线/散点/矢量整数 x 铺满域时刻在取样点、矢量头是场景三角（不是圆点）、误差棒、热图色条、热图格子按相邻坐标步长铺满且刻度落在格心（缝宽按格子比例，不是 1 场景单位；第一行在顶上；不画穿过格子的笛卡尔虚线）、图例外置、投稿 mm、SVG 更接近 Runtime、PDF 默认随包 CJK 子集（examples + 论文用字；`VIVA_PDF_CJK_FONT` / `--cjk-font` / `cjkFontPath` 可挂宿主全库）。`print-nature` 会覆盖 widget 硬编码字号，刻度 8 / 轴标题 9 带字距；plot / figure 甲板 / 外框圆角为 0（不再写死 6/8）。编译器按字号和 `unit: mm` 比例放置轴标题/刻度/图例；单图不写 `areaX`/`areaY` 时按场景估绘图区，并避开作者节点/手写 frame 占的空位，避免小栏宽把标题推出画布。  
没有：完整 CJK 字库、通用排版求解（跨页、栏宽文法）。有 time / box / violin（KDE 轮廓）/ 显著性括号；轴刻度已离开数据域。chrome 盒子会互推（标题避开 `(a)`，y 轴标题避开刻度，图例避开色条）；图/轴标题按栏宽折行（最多三行；封顶后尾行 `...`；Y 轴 −90° 后从上往下读），折行宽度按像素字宽量、落位按场景单位（mm 栏不再把 60 mm 当成 60 px），图例键和色条标签按剩余栏宽折行（含连字符，最多两行；无连字符的拉丁图例键先按整词让 inset，避免 `treatmen` / `t`；色条/右图例先让 inset，仍装不下才省略），热图可用 `zLabel`/`zUnit`（mm 色条按 px→场景比例画，标题在色标右侧 −90° 竖排；色条刻度落在 `zlim` 值上，不再只标底/中/顶三段；色带是顺序色 `linearGradient`），重叠刻度抽稀，相邻格 chrome 互叠时按溢出整量长 inset（互叠缝跟场景 `pad` 走）；inset 封顶是绘图区下限（约 22%），不再 38%/50% 侧帽；触底后标题/轴题/图例尽量收回格内，不推进刻度。审查 / Runtime / 结构检查共用旋转感知盒子（CJK 字宽，mm 场景先 `scaleSceneGeom`）。仍不是 InDesign。小栏宽 mm 图默认跟手 `__tip`（空字不画），不再靠常驻角 HUD。

### 3.3 图像 / 视频级排版

有：`layout.figure` 网格 + `(a)(b)` + 格子甲板；图表 `span: 2` 跨栏（插件属性，不是关键字）；不写 `inset*` 时编译器按该格 chart 的刻度/标题/图例/色条迭代估留白；不写 `x/y/w/h` 时铺满场景，或 `panel: body` 吃 board 槽；`title`/`subtitle`/`caption` 由编译器画；两张以上未绑 panel 的 chart 自动成网格并停在剩余空位；`layout.board` 的 `safe` / `title` / `body` / `lower` + 题注属性（`body:`/`prose` 折进 `left` 或 `body`；`caption:` ident 保持绑定）+ `splits` / `beats` / `bleed` / `typeGrid`；不写 `safe`/`titleH`/`lowerH` 时按题注折行和芯片宽度估条带，空题注不再占 72/96；board / storyboard 例子用 title/caption，不再手摆字幕条；`unit: mm` + 栏宽；`page: a4` 的 PDF 切片盖 `n / N`（续页可带 figure `(continued)`）；会被页刀切开的 figure 行整行进下一页，场景拉高；beat PNG 按 hold 中点导出，GIF/MP4 用同一 Clock 在 timeline fps 上采完整 hold+ease。
没有：真实字体约束排版、Runtime 页面导航、桌面 NLE、通用碰撞求解。`page: a4` 让 PDF 按页高切片，并在每页盖 `n / N`；续页顶栏重复 figure `(continued)` 或 board 题注。figure 格子避开页缝；`layout.board` 的 `body:` 在有 `page` 时按栏宽折行并避开页刀续到下一页。SVG/PNG 仍是一张长画布。这是页装箱 + 对页页戳（recto 右 / verso 左）+ 续页题注，不是可跳转的 Runtime 页面状态机，也不是章节标排版器。`typeGrid` 仍画安全框上的基线与 `type0`… 栏；`body:` / `prose` 会按可读栏宽（12 导轨合成 2–3 栏）灌进这些槽，从上到下再从左到右，仍不是 InDesign。这些必须继续是**插件**，不能变成语法。`play` 的视觉仍由拍遮罩合成。

---

## 4. 和常见代理内联汇报比，现在赢在哪、装在哪

| | 别人 | 愿景中的 Viva | 现在的 Viva |
| --- | --- | --- | --- |
| 生成物 | matplotlib / React / 静态图 | 可编译的活汇报件 | 能编，默认观感仍粗 |
| 改法 | 改代码重跑 | 改意图、热替换 | patch/session 接口在，产品环不在 |
| 交互 | 图是附件 | 图就是世界 | 默认有刷选/高亮，仍不是游戏级汇报 |
| 排版 | 手调或 CSS | 编译器网格 / 安全框 | figure + board + mm + bleed/typeGrid；无跨页成片 |
| 扩展 | 再学一个库 | 注册插件 | 手册 + widget 注册表 |

未齐三柱质量之前，**不要**说超过 Claude Science，也不要说 Nature 级。

---

## 5. 下一刀（只服务三柱，不铺路由）

1. 真实字体度量：layout / structural / SVG / PDF 统一字体和 metrics；当前假字宽会把 `iiiiiiii` 高估 161%，把 `WWWWWWWW` 低估 39%
2. PDF paint 保真：补 rotate / letterSpacing / gradient / dash / radius / 完整 path，并对同一件做 SVG↔PDF 栅格叠差
3. 一份规范到站件：同一短源码含 89 / 183 mm、CJK、World drag、brush、Clock play 和跨页
4. 真实 Runtime 浏览器考试 + 页面状态机：一次 session 连打刷、拖、翻拍、跳页、暗拍刷；分页目前只有导出，没有 `__page` 写入者
5. 关闭 Agent 环：产品与 exam 用同一真 slim prompt；多轮 compile/check/repair/re-prompt；最终判 PDF、行为和内联卡。完整退出条件见 [`ARRIVAL_AUDIT.md`](./ARRIVAL_AUDIT.md)

发现插件：`viva widgets` 或 `listWidgets()`。
